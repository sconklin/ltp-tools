        if (value < 0 or
            value > 100):
            print 'bad percent value'
